package syed.baqir.naqvi;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.StringTokenizer;
import java.util.stream.Stream;

//import syed.baqar.naqvi.StudentFileData;

public class Studentbatchprocess {
	// JDBC driver name and database URL
	
			static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
			static final String DB_URL = "jdbc:mysql://localhost";
			
			//static final String DB_URL = "jdbc:mysql://localhost/STUDENTS";
			static final String FILE_PATH = "C:\\workspace\\jdbcproject2\\JavaGitProjs\\HelloWorldJafar\\Data";
			static final String FILE_NAME = "StdData.txt";
	
			// Database credentials
			static final String USER = "SyedBaqir";
			static final String PASS = "SyedBaqir123";
			
	public static void main(String[] args) {
		
		Connection dbconn = null;
		boolean flag = false;
		try {
			// STEP 2: Register JDBC driver
			Class.forName(JDBC_DRIVER);

			// STEP 3: Open a connection without a database name to create a new database. It will connect to database system with Admin permissions
			System.out.println("Connecting to database...");
			dbconn = DriverManager.getConnection(DB_URL, USER, PASS);//DB_URL = "jdbc:mysql://localhost"
			Path filePath = Paths.get(FILE_PATH , FILE_NAME);
			saveStudentData(dbconn, filePath);
			
			
			
			dbconn.close();
			
						
			
			
		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} // end try

		System.out.println("Goodbye!");
		
	}
	
	public static void saveStudentData(Connection dbconn, Path fullFilePath) {
		
		
		try (Stream<String> lines = Files.lines( fullFilePath )) 
		{
		   // lines.sorted().forEach(System.out::println);
		   // System.out.println(lines.count());
			lines.forEach(str -> 
			{
				String[] split = str.split(" ");
				String name;
				String score;
				int attendance;
				String grade;
				
				name =  split[0];
				score = split[1];
				grade = split[2];
				attendance = Integer.parseInt(split[3]);
				
			}
			);
		   
		} 
		catch (IOException e) 
		{
		    e.printStackTrace();
		}
		System.out.println("Save Student Data mehtod");
	}

}
