package com.math.sequences;

import java.util.Scanner;

public class MainDriverClass {

	public static void main(String[] args) {

		 Scanner input = new Scanner(System.in);
		int []sequence = new int[50];
	      System.out.println("Input the sequence and finish by entering 0");
	      int n;
	      int index = 0;
	      while ((n = input.nextInt()) != 0) {
	        sequence[index] = n;
	        index++;
	        System.out.println("Input an integer");
	     }
	     
	      System.out.println("Your sequence is");
	      for(int i = 0; i < index; i++) {
	    	  System.out.print(sequence[i] + ", ");
	      }
	      
	      System.out.println("\n How many term you want to sum in this sequence?");
	      int nth = input.nextInt();
	      int sum = 0;
	      int a = sequence[0];
	      int d = (sequence[1] - sequence[0]);
	      sum = nth/2  * ( (2 * a) + ( (nth - 1) * d ) );
	      System.out.println("\n Sum of Your sequence is = " + sum);
	      int nthTerm = a + (nth -1) * d;
	      System.out.println("\n" + nth + "term of Your sequence is = " + nthTerm);
	}


}
